class Stack {
     int arr[] =  new int[5];
	 int top1;
	 int top2;
	 Stack(){
	    top1 = -1;
		top2 = arr.length;
	 }
	 boolean push1(int x ){
		if(top1 == top2 -1 ){
			
			System.out.println("Popped element from stack1 is"+ arr[top1]);
			top2=top2+1;
			System.out.println("Popped element from stack2 is"+ x);
			return false;
		}
		arr[top1+1] = x;
		top1 = top1+1;
		return true;
	 }
	 boolean push2(int x ){
		if(top1 == top2 -1 ){
			
			System.out.println("Popped element from stack1 is"+ arr[top1]);
			top1=top1-1;
			System.out.println("Popped element from stack2 is"+ x);
			return false;
		}
		arr[top2-1] = x;
		top2 = top2-1;
		return true;
	 }
	 int pop1(){
	   if(top1==-1){
	     System.out.println("Underflow");
		 new RuntimeException("Underflow");
	   }
	   int x = top1;
	   top1=top1-1;
	   return x;
	 }
	 int pop2(){
	   if(top2==arr.length){
	     System.out.println("Underflow");
		 new RuntimeException("Underflow");
	   }
	   int x = top2;
	   top2=top2+1;
	   return x;
	 }
	 public static void main(String [] args ){
		Stack st = new Stack();
		st.push1(5);
		st.push2(10);
		st.push2(15);
		st.push1(11);
		st.push2(7);
		st.push2(40);
	 
	 }
}
	