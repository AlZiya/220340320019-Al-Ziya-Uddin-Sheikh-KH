import java.util.Scanner;
class Node {
	 int info;
	 Node link;
	
	 Node (int i){
		info = i;
		link = null;
	}

}

class SingleLinkedList{

	Node start;
	SingleLinkedList(){
		start = null;
	}
	void add (int x){
	     Node  nd = new Node(x);
		 if(start == null){
		  
		  start= nd;
		  return ;
		 }		
	     Node current = start;			 
		 while( current.link !=null){
			current = current.link;
		 }
		 current.link=nd;
		
	}
	static void printList(Node head ){
		while(head!=null){
				System.out.print(head.info+"->");
				head=head.link;
		}
		System.out.println("X");
	}
	
	static Node reverseList(Node head){
		Node prev , p , next;
		prev = null;
		p = head;
		while(p!= null){
			next = p.link;
			p.link = prev;
			prev=p;
			p= next;
			
		}
		//start = prev;
		return prev;
		
	}
	 public static void main(String [] args){
		 
		 Scanner sc = new Scanner(System.in);
		 int t = sc.nextInt();
		  while( t!=0){
			 SingleLinkedList sl =  new SingleLinkedList(); 
             int n = sc.nextInt();
			 for(int i = 0 ; i < n ; i++ ){
				sl.add(sc.nextInt());
			 }
				sl.start = reverseList(sl.start);
             	printList(sl.start);		 
			t--;
		}  
    }
}

