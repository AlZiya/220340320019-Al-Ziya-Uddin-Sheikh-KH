import java.util.Scanner;
class Sorting{
    
	public static void print(int [] arr){
	
	    for(int i = 0 ; i < arr.length; i++ ){
			System.out.print(arr[i]+" ");
		}
		    System.out.println();
	}
	public static void main(String [] args){
		
			Scanner sc = new Scanner(System.in);
			int n = sc.nextInt();
			int arr[] = new int[n];
			for(int i = 0; i < n; i++)
					 arr[i] = sc.nextInt();
					print(arr); 
			for( int i = 1 ; i <arr.length; i++){
				int temp = arr[i];
				int j;
				for( j = i -1; j>=0 && arr[j] > temp;j--){
				
					
						arr[j+1]=arr[j];
						print(arr);
					}
					
				
				arr[j+1]=temp;
				
			}
				
	}
}
			
